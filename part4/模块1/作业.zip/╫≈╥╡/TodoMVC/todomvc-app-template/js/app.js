(function (window) {
	'use strict';

	let filters = {
		all (todos) {
			return todos
		},
		active (todos) {
			return todos.filter(todo => !todo.completed)
		},
		completed (todos) {
			return todos.filter(todo => todo.completed)
		}
	}

	const TODOS_KEY = 'todos-vue'
	let todoStorage = {
		get () {
			return JSON.parse(localStorage.getItem(TODOS_KEY)) || []
		},
		set (todos) {
			localStorage.setItem(TODOS_KEY, JSON.stringify(todos))
		}
	}
	new Vue({
		el: '#app',
		data: {
			todos: todoStorage.get(),
			// 存储新增输入框的内容
			newTodo: '',
			editingTodo: null,
			titleBeforeEdit: '',
			todoType: 'all'
		},
		watch: {
			todos: {
				deep: true,
				handler: todoStorage.set
			}
		},
		computed: {
			filteredTodo () {
				return filters[this.todoType](this.todos)
			},
			// 用于存储未完成事项个数
			remaining() {
				return filters['active'](this.todos).length
			},
			allDone: {
				get() {
					return this.remaining === 0
				},
				set(value) {
					this.todos.forEach(todo => {
						todo.completed = value
					})
				}
			}
		},
		methods: {
			// 用于单位复数化处理
			pluralize() {
				return this.remaining === 1 ? 'item' : 'items'
			},
			// 新增事项
			addTodo() {
				let value = this.newTodo.trim()
				if (!value) return
				this.todos.push({ id: this.todos.length + 1, title: value, completed: false })
				this.newTodo = ''
			},
			// 删除事项
			removeTodo(todo) {
				let index = this.todos.indexOf(todo)
				this.todos.splice(index, 1)
			},
			removeCompleted() {
				// this.todos = this.todos.filter(todo => !todo.completed)
				this.todos = filters.active(this.todos)
			},
			// 设置编辑保存内容
			editTodo(todo) {
				this.editingTodo = todo,
					this.titleBeforeEdit = todo.title
			},
			// 取消保存
			cancleEdit(todo) {
				this.editingTodo = null
				todo.title = this.titleBeforeEdit
			},
			// 保存编辑
			editDone(todo) {
				if (!this.editingTodo) return
				this.editingTodo = null
				todo.title = todo.title.trim()
				if (!todo.title) {
					this.removeTodo(todo)
				}
			}
		},
		directives: {
			// 双击自动获取焦点
			'todo-focus'(el, binding) {
				if (binding.value) {
					el.focus()
				}
			}
		}
	})

})(window);

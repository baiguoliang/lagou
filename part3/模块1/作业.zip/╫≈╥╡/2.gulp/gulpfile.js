// 引入模块
const {src, dest, parallel, series, watch} =require('gulp')
const cleancss = require('gulp-clean-css')
const rename = require('gulp-rename')
const autoprefixer = require('gulp-autoprefixer')
const htmlmin = require('gulp-htmlmin')
const del = require('del')
const browserSync = require('browser-sync')
const bs = browserSync.create()

// 声明样式构建任务
const style = () => {
  return src('src/css/index.css', {base: 'src'})
  .pipe(autoprefixer())
  .pipe(cleancss())
  .pipe(rename({ "extname": ".min.css" }))
  .pipe(dest('dist'))
}

// 声明脚本构建任务
const script = () => {
  return src('src/js/**', { base: 'src' })
  .pipe(dest('dist'))
}

// 声明页面构建任务
const html = () => {
  return src('src/index.html', { base: 'src' })
  .pipe(htmlmin({
    collapseWhitespace: true,
    minifyJS: true
  }))
  .pipe(dest('dist'))
}

// 传递 json 文件
const json = () => {
  return src('src/db.json', {base: 'src'})
  pipe(dest('dist'))
}

// 声明清除目录任务
const clean = () => {
  return del(['dist'])
}

// 声明服务发布任务
const serve = () => {
  watch('src/index.html', html)
  watch('src/css/index.css', style)
  bs.init({
    notify: false,
    files: 'dist/**',
    server: {
      baseDir: './dist',
      routes: {
        '/node_modules': 'node_modules'
      }
    }
  })
}

// 组合任务
const build = parallel(style, script, html, json)
const dev = series(clean, build, serve)

// 导出任务
module.exports = {
  build,
  dev,
  serve
}
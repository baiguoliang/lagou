const fs = require('fs')
const path = require('path')

const dist = path.join(__dirname, 'dist')

fs.readFile('src/main.css', (err, data) => {
  if (err) {
    throw err
  } else {

    if (!fs.existsSync(dist)) {
      fs.mkdirSync(dist)
    }

    var mydata = data.toString().replace(/\s+/g, '')

    fs.writeFile(dist + '/main.css', mydata, (err) => {
      if (err) throw err
      console.log('成功')
    })

    fs.renameSync(dist + '/main.css', dist + '/mian.min.css', (err) => {
      if (err) throw err
      console.log('重命名成功')
    })

    fs.unlinkSync(__dirname + '/src/main.css', (err) => {
      if (err) throw err
    })
  }
})